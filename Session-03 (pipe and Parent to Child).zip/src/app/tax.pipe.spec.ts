import { TaxPipe } from './tax.pipe';

describe('TaxPipe', () => {
  it('create an instance', () => {
    const pipe = new TaxPipe();
    expect(pipe).toBeTruthy();
  });
});
