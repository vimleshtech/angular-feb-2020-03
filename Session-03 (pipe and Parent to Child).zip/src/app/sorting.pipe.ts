import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sorting'
})
export class SortingPipe implements PipeTransform {

  transform(value:any, order:string): any {

    if(order=='asc'){

      return value.sort(); //arrange in asc order
    }
    else { //arrange in desc order 
      return value.sort().reverse();
    }
    
  }

}
