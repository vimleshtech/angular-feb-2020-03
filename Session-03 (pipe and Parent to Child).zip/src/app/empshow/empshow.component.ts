import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-empshow',
  templateUrl: './empshow.component.html',
  styleUrls: ['./empshow.component.css']
})
export class EmpshowComponent implements OnInit {

  //receive data from parent 
  @Input()
  empdata

  constructor() { 
    
  }

  ngOnInit() {
  }

}
