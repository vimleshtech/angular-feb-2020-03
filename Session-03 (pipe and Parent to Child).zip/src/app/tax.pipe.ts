import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tax'
})
export class TaxPipe implements PipeTransform {

  transform(value: number, country:string, type:string ): any {

    var  total=0;
    var taxamt =0;
    
    value = parseInt(value);

    if(country=='india' && type=='food'){

      taxamt = value*.05;
    }else if(country=='india' && type=='ele'){
      
            taxamt = value*.18;
      }
      else if(country=='india' && type=='other'){
        
              taxamt = value*.12;
        }
        else if(country=='us' && type=='food'){
          
                taxamt = value*.10;
          }
          else if(country=='us' && type=='other'){
            
                  taxamt = value*.25;
            }
            
      console.log(value);
      console.log(country);
      console.log(taxamt);

      total  = value+taxamt;
      console.log(total);
      return total;
  }

}
